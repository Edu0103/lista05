﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtN1.Text);
            float num3 = float.Parse(txtN3.Text);
            float resultado;
            resultado = num1 + num3;
            lblResultadoSoma.Text = "Soma igual a " + resultado;
              
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtN1.Text);
            float num2 = float.Parse(txtN2.Text);
            float num3 = float.Parse(txtN3.Text);
            float resultado;
            resultado = (num1 + num3 + num2)/3;
            lblResultadoMedia.Text = "Media igual a " + resultado;
        }

        private void btnPorcento_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtN1.Text);
            float num2 = float.Parse(txtN2.Text);
            float num3 = float.Parse(txtN3.Text);
            float total,porcento1,porcento2,porcento3;
            total = (num1 + num3 + num2);
            porcento1 = (num1 / total)*100;
            porcento2 = (num2 / total) * 100;
            porcento3 = (num3 / total) * 100;
            lblResultadoPorcento.Text = " Número 1 é de " + porcento1 + "%, Número 2 é de " + porcento2 + "%,  Número 3 é de " + porcento3 +"%";
        }
    }
}
