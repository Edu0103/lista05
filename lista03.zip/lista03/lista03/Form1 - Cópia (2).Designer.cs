﻿namespace lista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblN1 = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.lblN2 = new System.Windows.Forms.Label();
            this.txtN3 = new System.Windows.Forms.TextBox();
            this.lblN3 = new System.Windows.Forms.Label();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcento = new System.Windows.Forms.Button();
            this.lblResultadoSoma = new System.Windows.Forms.Label();
            this.lblResultadoMedia = new System.Windows.Forms.Label();
            this.lblResultadoPorcento = new System.Windows.Forms.Label();
            this.lblExercicio1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.Location = new System.Drawing.Point(133, 183);
            this.lblN1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(78, 20);
            this.lblN1.TabIndex = 0;
            this.lblN1.Text = "Número 1";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(137, 238);
            this.txtN1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(148, 26);
            this.txtN1.TabIndex = 1;
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(325, 238);
            this.txtN2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(148, 26);
            this.txtN2.TabIndex = 3;
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.Location = new System.Drawing.Point(321, 183);
            this.lblN2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(78, 20);
            this.lblN2.TabIndex = 2;
            this.lblN2.Text = "Número 2";
            // 
            // txtN3
            // 
            this.txtN3.Location = new System.Drawing.Point(530, 238);
            this.txtN3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtN3.Name = "txtN3";
            this.txtN3.Size = new System.Drawing.Size(148, 26);
            this.txtN3.TabIndex = 5;
            // 
            // lblN3
            // 
            this.lblN3.AutoSize = true;
            this.lblN3.Location = new System.Drawing.Point(526, 183);
            this.lblN3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblN3.Name = "lblN3";
            this.lblN3.Size = new System.Drawing.Size(78, 20);
            this.lblN3.TabIndex = 4;
            this.lblN3.Text = "Número 3";
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(134, 323);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(150, 87);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "a)Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(325, 323);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(150, 87);
            this.btnMedia.TabIndex = 7;
            this.btnMedia.Text = "b)Media";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorcento
            // 
            this.btnPorcento.Location = new System.Drawing.Point(519, 323);
            this.btnPorcento.Name = "btnPorcento";
            this.btnPorcento.Size = new System.Drawing.Size(150, 87);
            this.btnPorcento.TabIndex = 8;
            this.btnPorcento.Text = "c)Porcentagem";
            this.btnPorcento.UseVisualStyleBackColor = true;
            this.btnPorcento.Click += new System.EventHandler(this.btnPorcento_Click);
            // 
            // lblResultadoSoma
            // 
            this.lblResultadoSoma.AutoSize = true;
            this.lblResultadoSoma.Location = new System.Drawing.Point(349, 458);
            this.lblResultadoSoma.Name = "lblResultadoSoma";
            this.lblResultadoSoma.Size = new System.Drawing.Size(132, 20);
            this.lblResultadoSoma.TabIndex = 9;
            this.lblResultadoSoma.Text = "Resultado Soma:";
            // 
            // lblResultadoMedia
            // 
            this.lblResultadoMedia.AutoSize = true;
            this.lblResultadoMedia.Location = new System.Drawing.Point(349, 500);
            this.lblResultadoMedia.Name = "lblResultadoMedia";
            this.lblResultadoMedia.Size = new System.Drawing.Size(133, 20);
            this.lblResultadoMedia.TabIndex = 10;
            this.lblResultadoMedia.Text = "Resultado Media:";
            // 
            // lblResultadoPorcento
            // 
            this.lblResultadoPorcento.AutoSize = true;
            this.lblResultadoPorcento.Location = new System.Drawing.Point(349, 542);
            this.lblResultadoPorcento.Name = "lblResultadoPorcento";
            this.lblResultadoPorcento.Size = new System.Drawing.Size(185, 20);
            this.lblResultadoPorcento.TabIndex = 11;
            this.lblResultadoPorcento.Text = "Resultado Porcentagem:";
            // 
            // lblExercicio1
            // 
            this.lblExercicio1.AutoSize = true;
            this.lblExercicio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio1.Location = new System.Drawing.Point(91, 42);
            this.lblExercicio1.Name = "lblExercicio1";
            this.lblExercicio1.Size = new System.Drawing.Size(202, 31);
            this.lblExercicio1.TabIndex = 12;
            this.lblExercicio1.Text = "EXERCÍCIO 01";
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.lblExercicio1);
            this.Controls.Add(this.lblResultadoPorcento);
            this.Controls.Add(this.lblResultadoMedia);
            this.Controls.Add(this.lblResultadoSoma);
            this.Controls.Add(this.btnPorcento);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtN3);
            this.Controls.Add(this.lblN3);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.lblN1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmExercicio01";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.TextBox txtN3;
        private System.Windows.Forms.Label lblN3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcento;
        private System.Windows.Forms.Label lblResultadoSoma;
        private System.Windows.Forms.Label lblResultadoMedia;
        private System.Windows.Forms.Label lblResultadoPorcento;
        private System.Windows.Forms.Label lblExercicio1;
    }
}

