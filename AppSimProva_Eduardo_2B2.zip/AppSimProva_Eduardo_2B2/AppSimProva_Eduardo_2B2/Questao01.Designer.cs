﻿namespace AppSimProva_Eduardo_2B2
{
    partial class FrmQuestao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblCEMIG = new System.Windows.Forms.Label();
            this.lblConta = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblKh = new System.Windows.Forms.Label();
            this.lblQnt = new System.Windows.Forms.Label();
            this.lblDias = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtKh = new System.Windows.Forms.TextBox();
            this.txtQnt = new System.Windows.Forms.TextBox();
            this.txtDias = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.lblConta);
            this.panel1.Controls.Add(this.lblCEMIG);
            this.panel1.Location = new System.Drawing.Point(0, -3);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1204, 145);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(2, 142);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1202, 32);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel3.Controls.Add(this.lblTotal);
            this.panel3.Controls.Add(this.txtDias);
            this.panel3.Controls.Add(this.txtQnt);
            this.panel3.Controls.Add(this.txtKh);
            this.panel3.Controls.Add(this.txtNome);
            this.panel3.Controls.Add(this.btnCalcular);
            this.panel3.Controls.Add(this.lblDias);
            this.panel3.Controls.Add(this.lblQnt);
            this.panel3.Controls.Add(this.lblKh);
            this.panel3.Controls.Add(this.lblNome);
            this.panel3.Location = new System.Drawing.Point(2, 172);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1200, 523);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // lblCEMIG
            // 
            this.lblCEMIG.AutoSize = true;
            this.lblCEMIG.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCEMIG.Location = new System.Drawing.Point(38, 47);
            this.lblCEMIG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCEMIG.Name = "lblCEMIG";
            this.lblCEMIG.Size = new System.Drawing.Size(150, 46);
            this.lblCEMIG.TabIndex = 0;
            this.lblCEMIG.Text = "CEMIG";
            this.lblCEMIG.Click += new System.EventHandler(this.lblCEMIG_Click);
            // 
            // lblConta
            // 
            this.lblConta.AutoSize = true;
            this.lblConta.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConta.Location = new System.Drawing.Point(642, 84);
            this.lblConta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblConta.Name = "lblConta";
            this.lblConta.Size = new System.Drawing.Size(141, 26);
            this.lblConta.TabIndex = 1;
            this.lblConta.Text = "Conta de Luz";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(268, 7);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(224, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome da Empresa/Residência";
            // 
            // lblKh
            // 
            this.lblKh.AutoSize = true;
            this.lblKh.Location = new System.Drawing.Point(40, 108);
            this.lblKh.Name = "lblKh";
            this.lblKh.Size = new System.Drawing.Size(99, 20);
            this.lblKh.TabIndex = 1;
            this.lblKh.Text = "Valor em Kh:";
            // 
            // lblQnt
            // 
            this.lblQnt.AutoSize = true;
            this.lblQnt.Location = new System.Drawing.Point(284, 108);
            this.lblQnt.Name = "lblQnt";
            this.lblQnt.Size = new System.Drawing.Size(180, 20);
            this.lblQnt.TabIndex = 2;
            this.lblQnt.Text = "Quantidade Consumida:";
            // 
            // lblDias
            // 
            this.lblDias.AutoSize = true;
            this.lblDias.Location = new System.Drawing.Point(597, 108);
            this.lblDias.Name = "lblDias";
            this.lblDias.Size = new System.Drawing.Size(120, 20);
            this.lblDias.TabIndex = 3;
            this.lblDias.Text = "Dias em atraso:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(193, 289);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(401, 64);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(147, 42);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(468, 26);
            this.txtNome.TabIndex = 5;
            // 
            // txtKh
            // 
            this.txtKh.Location = new System.Drawing.Point(26, 151);
            this.txtKh.Name = "txtKh";
            this.txtKh.Size = new System.Drawing.Size(130, 26);
            this.txtKh.TabIndex = 6;
            // 
            // txtQnt
            // 
            this.txtQnt.Location = new System.Drawing.Point(312, 151);
            this.txtQnt.Name = "txtQnt";
            this.txtQnt.Size = new System.Drawing.Size(130, 26);
            this.txtQnt.TabIndex = 7;
            // 
            // txtDias
            // 
            this.txtDias.Location = new System.Drawing.Point(587, 151);
            this.txtDias.Name = "txtDias";
            this.txtDias.Size = new System.Drawing.Size(130, 26);
            this.txtDias.TabIndex = 8;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.YellowGreen;
            this.lblTotal.Location = new System.Drawing.Point(21, 229);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(485, 29);
            this.lblTotal.TabIndex = 9;
            this.lblTotal.Text = "A empresa:  , deve pagar o valor total de: R$\r\n";
            // 
            // FrmQuestao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 537);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmQuestao1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblConta;
        private System.Windows.Forms.Label lblCEMIG;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtDias;
        private System.Windows.Forms.TextBox txtQnt;
        private System.Windows.Forms.TextBox txtKh;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblDias;
        private System.Windows.Forms.Label lblQnt;
        private System.Windows.Forms.Label lblKh;
        private System.Windows.Forms.Label lblTotal;
    }
}

