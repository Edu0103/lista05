﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Eduardo_2B2
{
    public partial class FrmQuestao1 : Form
    {
        public FrmQuestao1()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblCEMIG_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double valorKw = double.Parse(txtKh.Text);
            double valorQnt = double.Parse(txtQnt.Text);
            double valorDias = double.Parse(txtDias.Text);
            double resultado;
            string nome = (txtNome.Text);
            resultado = (valorKw * valorQnt) + (valorKw * valorQnt * 1.5f/100 * valorDias);
            lblTotal.Text = "A empresa: " + nome + ", deve pagar o valor total de: R$" + resultado; 
        }
    }
    }