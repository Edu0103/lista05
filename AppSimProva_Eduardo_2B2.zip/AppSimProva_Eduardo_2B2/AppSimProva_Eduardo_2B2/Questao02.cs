﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Eduardo_2B2
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);
            float total1, total2, total3;
            total1 = (valor1 * 10 / 100) + valor1;
            total2 = (valor2 * 10 / 100) + valor2;
            total3 = (valor3 * 10 / 100) + valor3;
            lblTotal.Text = "Resultado:O valor 1 deu: " + total1 + ", o valor 2 deu: " + total2 + " e o valor 3 deu: "+total3;
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtValor1.Clear();
            txtValor2.Clear();
            txtValor3.Clear();

            lblTotal.Text = "";
        }
    }
}
